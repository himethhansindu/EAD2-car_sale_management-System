# car-sall-management-system
 The car sell management system only for admin. There are 4 microServices with backend. Seller, Buyer, Car_management and next js UI
